I would just like to clarify that for the Tank, I created two independent Finite State Machines. One handles tank movement and the other handles tank shooting. I’ve named them Movement FSM and Shooting FSM, respectively.

— Rafael Angelo